
package com.salafacil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalaFacilApplication {
    public static void main(String[] args) {
        SpringApplication.run(SalaFacilApplication.class, args);
    }
}
