
package com.salafacil.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Reserva {
 @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 @ManyToOne
 private Usuario usuario;

 @ManyToOne
 private Sala sala;

 private LocalDateTime inicio;
 private LocalDateTime fim;

 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }
 public Usuario getUsuario() { return usuario; }
 public void setUsuario(Usuario usuario) { this.usuario = usuario; }
 public Sala getSala() { return sala; }
 public void setSala(Sala sala) { this.sala = sala; }
 public LocalDateTime getInicio() { return inicio; }
 public void setInicio(LocalDateTime inicio) { this.inicio = inicio; }
 public LocalDateTime getFim() { return fim; }
 public void setFim(LocalDateTime fim) { this.fim = fim; }
}
