
package com.salafacil.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.salafacil.model.Sala;

public interface SalaRepository extends JpaRepository<Sala, Long> {}
